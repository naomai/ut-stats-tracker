                                        
            dddddddd                     
            d::::::dUUUUUUUU     UUUUUUUU
            d::::::dU::::::U     U::::::U
            d::::::dU::::::U     U::::::U
            d:::::d UU:::::U     U:::::UU
    ddddddddd:::::d  U:::::U     U:::::U 
  dd::::::::::::::d  U:::::D     D:::::U 
 d::::::::::::::::d  U:::::D     D:::::U 
d:::::::ddddd:::::d  U:::::D     D:::::U 
d::::::d    d:::::d  U:::::D     D:::::U 
d:::::d     d:::::d  U:::::D     D:::::U 
d:::::d     d:::::d  U:::::D     D:::::U 
d:::::d     d:::::d  U::::::U   U::::::U 
d::::::ddddd::::::dd U:::::::UUU:::::::U 
 d:::::::::::::::::d  UU:::::::::::::UU  
  d:::::::::ddd::::d    UU:::::::::UU    
   ddddddddd   ddddd      UUUUUUUUU      
                                         
This file is downloaded from http://www.destinationunreal.com

We are not a clan, simply a community where everyone can participate.
destination Unreal now exists since 2007. For that time we play games that have anything to do with Unreal Tournament.
Our main focus is on fighting monsters.
We offer the community a number of UT99 (MonsterHunt, MonsterAttack, Coop) and UT3 (GaltanorsInvasion) game servers.                                         

We look forward to each new player.